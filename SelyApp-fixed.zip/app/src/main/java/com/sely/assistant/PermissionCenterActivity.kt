package com.sely.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class PermissionCenterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permission_center)
        findViewById<android.widget.ImageButton>(R.id.backButton).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        refreshRows() // statuses can change after returning from system Settings
    }

    private fun refreshRows() {
        bindPermissionRow(
            R.id.rowMic, R.drawable.ic_mic, "Microphone",
            "Needed for \"Hey Sely\" and voice commands.",
            hasPermission(Manifest.permission.RECORD_AUDIO)
        ) { requestPermission(Manifest.permission.RECORD_AUDIO, 10) }

        bindPermissionRow(
            R.id.rowAccessibility, R.drawable.ic_assistant, "Accessibility Service",
            "Needed for tapping, scrolling, typing, and reading supported app screens.",
            isAccessibilityServiceEnabled()
        ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        } else true
        bindPermissionRow(
            R.id.rowNotif, R.drawable.ic_bell, "Notifications",
            "Needed for reminders and the always-listening status notification.",
            notifGranted
        ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestPermission(Manifest.permission.POST_NOTIFICATIONS, 11)
            } else {
                openAppNotificationSettings()
            }
        }

        bindPermissionRow(
            R.id.rowContacts, R.drawable.ic_profile, "Contacts",
            "Needed to call or message someone by name.",
            hasPermission(Manifest.permission.READ_CONTACTS)
        ) { requestPermission(Manifest.permission.READ_CONTACTS, 12) }

        bindPermissionRow(
            R.id.rowCamera, R.drawable.ic_globe, "Camera (flashlight)",
            "Needed to turn the flashlight on and off.",
            hasPermission(Manifest.permission.CAMERA)
        ) { requestPermission(Manifest.permission.CAMERA, 13) }

        bindPermissionRow(
            R.id.rowPhone, R.drawable.ic_chat, "Phone & Call Log",
            "Needed to answer calls and read who's calling.",
            hasPermission(Manifest.permission.READ_PHONE_STATE)
        ) { requestPermission(Manifest.permission.READ_PHONE_STATE, 14) }

        bindPermissionRow(
            R.id.rowWriteSettings, R.drawable.ic_theme, "Modify System Settings",
            "Optional — only needed for voice-controlled screen brightness.",
            Settings.System.canWrite(this)
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun bindPermissionRow(
        includeId: Int, iconRes: Int, title: String, subtitle: String, granted: Boolean, onClick: () -> Unit
    ) {
        val row = findViewById<android.view.View>(includeId)
        row.findViewById<ImageView>(R.id.rowIcon).setImageResource(iconRes)
        row.findViewById<TextView>(R.id.rowTitle).text = title
        val statusPrefix = if (granted) "Granted \u2713  \u2014  " else "Off  \u2014  "
        row.findViewById<TextView>(R.id.rowSubtitle).text = statusPrefix + subtitle
        row.findViewById<TextView>(R.id.rowSubtitle).visibility = android.view.View.VISIBLE
        row.setOnClickListener { onClick() }
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun requestPermission(permission: String, code: Int) {
        ActivityCompat.requestPermissions(this, arrayOf(permission), code)
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${SelyAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun openAppNotificationSettings() {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        intent.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        startActivity(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshRows()
    }
}
