package com.sely.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class VoiceAssistantActivity : AppCompatActivity(), SelyCommandProcessor.Callbacks {

    private lateinit var stateText: TextView
    private lateinit var recognizedText: TextView
    private lateinit var hintPill: TextView
    private lateinit var micButton: FrameLayout

    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var textToSpeech: TextToSpeech
    private var ttsReady = false
    private val commandProcessor by lazy { SelyCommandProcessor(this, this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voice_assistant)

        stateText = findViewById(R.id.voiceStateText)
        recognizedText = findViewById(R.id.voiceRecognizedText)
        hintPill = findViewById(R.id.voiceHintPill)
        micButton = findViewById(R.id.voiceMicButton)
        val backButton = findViewById<ImageButton>(R.id.voiceBackButton)

        backButton.setOnClickListener { finish() }
        micButton.setOnClickListener { onMicTapped() }

        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val prefs = getSharedPreferences("sely_prefs", MODE_PRIVATE)
                textToSpeech.language = Locale.forLanguageTag(prefs.getString("sely_language", "en-US") ?: "en-US")
                ttsReady = true
            }
        }
    }

    private fun onMicTapped() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 200)
            return
        }
        if (speechRecognizer != null) return
        startListening()
    }

    private fun startListening() {
        val recognizer = SpeechRecognizerFactory.create(this)
        if (recognizer == null) {
            Toast.makeText(this, "Speech recognition isn't available on this device", Toast.LENGTH_SHORT).show()
            return
        }
        speechRecognizer = recognizer
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                stateText.text = "Listening..."
                hintPill.text = "Listening..."
                hintPill.visibility = TextView.VISIBLE
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                stateText.text = "Thinking..."
                hintPill.visibility = TextView.INVISIBLE
            }
            override fun onError(error: Int) {
                cleanupRecognizer()
                stateText.text = "Tap the mic and speak"
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                cleanupRecognizer()
                if (text.isNullOrBlank()) {
                    stateText.text = "Tap the mic and speak"
                } else {
                    recognizedText.text = "\u201C$text\u201D"
                    stateText.text = "Thinking..."
                    commandProcessor.process(text.lowercase())
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
        }
        recognizer.startListening(intent)
    }

    private fun cleanupRecognizer() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    override fun speak(text: String, onDone: (() -> Unit)?) {
        runOnUiThread {
            stateText.text = "Speaking..."
            recognizedText.text = text
            if (ttsReady) {
                textToSpeech.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        runOnUiThread {
                            stateText.text = "Tap the mic and speak"
                            onDone?.invoke()
                        }
                    }
                    override fun onError(utteranceId: String?) {
                        runOnUiThread {
                            stateText.text = "Tap the mic and speak"
                            onDone?.invoke()
                        }
                    }
                })
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sely_voice_activity")
            } else {
                stateText.text = "Tap the mic and speak"
                onDone?.invoke()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        }
    }

    override fun onDestroy() {
        cleanupRecognizer()
        textToSpeech.stop()
        textToSpeech.shutdown()
        super.onDestroy()
    }
}
