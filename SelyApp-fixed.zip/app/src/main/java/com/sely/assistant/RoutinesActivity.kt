package com.sely.assistant

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.sely.assistant.engine.RoutineManager

class RoutinesActivity : AppCompatActivity() {

    private lateinit var routinesList: LinearLayout
    private lateinit var emptyText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_routines)
        findViewById<ImageButton>(R.id.backButton).setOnClickListener { finish() }
        routinesList = findViewById(R.id.routinesList)
        emptyText = findViewById(R.id.emptyText)
    }

    override fun onResume() {
        super.onResume()
        renderRoutines()
    }

    private fun renderRoutines() {
        routinesList.removeAllViews()
        val routines = RoutineManager.listRoutines(this)
        emptyText.visibility = if (routines.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE

        routines.forEach { (name, steps) ->
            val row = LayoutInflater.from(this).inflate(R.layout.item_routine, routinesList, false)
            row.findViewById<TextView>(R.id.routineName).text = name.replaceFirstChar { it.uppercase() }
            row.findViewById<TextView>(R.id.routineSteps).text = steps.joinToString(" \u2192 ")
            row.findViewById<ImageButton>(R.id.runButton).setOnClickListener {
                Toast.makeText(this, "Running $name...", Toast.LENGTH_SHORT).show()
                SelyCommandProcessor(this, ToastCallbacks(this)).process("run routine $name")
            }
            row.findViewById<ImageButton>(R.id.deleteButton).setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Delete routine?")
                    .setMessage("This removes \"$name\" permanently.")
                    .setPositiveButton("Delete") { _, _ ->
                        RoutineManager.deleteRoutine(this, name)
                        renderRoutines()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            routinesList.addView(row)
        }
    }

    /** Minimal Callbacks impl so a routine run from this screen can still speak its results. */
    private class ToastCallbacks(private val activity: AppCompatActivity) : SelyCommandProcessor.Callbacks {
        override fun speak(text: String, onDone: (() -> Unit)?) {
            activity.runOnUiThread {
                Toast.makeText(activity, text, Toast.LENGTH_SHORT).show()
                onDone?.invoke()
            }
        }
    }
}
