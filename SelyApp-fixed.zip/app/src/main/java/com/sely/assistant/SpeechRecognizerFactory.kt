package com.sely.assistant

import android.content.Context
import android.os.Build
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * Creates exactly one [SpeechRecognizer], preferring Android's on-device recognizer
 * (works fully offline, no audio leaves the device) when the OS and device support it,
 * and falling back to the normal (usually network-backed) recognizer otherwise.
 *
 * Callers are still responsible for making sure only one recognizer/session exists at a
 * time — this factory just decides *which kind* of recognizer to build.
 */
object SpeechRecognizerFactory {

    private const val TAG = "SpeechRecognizerFactory"

    fun create(context: Context): SpeechRecognizer? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                if (SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) {
                    Log.i(TAG, "Using on-device (offline) speech recognizer")
                    return SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                }
            } catch (e: Exception) {
                Log.e(TAG, "On-device recognizer unavailable, falling back", e)
            }
        }
        return if (SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.i(TAG, "Using default (online) speech recognizer")
            SpeechRecognizer.createSpeechRecognizer(context)
        } else {
            Log.e(TAG, "No speech recognition service available on this device")
            null
        }
    }
}
