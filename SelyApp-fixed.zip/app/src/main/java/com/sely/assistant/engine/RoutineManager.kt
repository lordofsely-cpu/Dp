package com.sely.assistant.engine

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Routines are stored as {name -> [raw command strings]} and replayed by feeding each saved
 * command back through the normal local-first command pipeline — so a routine step is exactly
 * as safe and capable as typing that step by hand, never more.
 */
object RoutineManager {
    private const val PREFS_KEY = "sely_routines"

    private fun prefs(context: Context) =
        context.getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)

    fun listRoutines(context: Context): Map<String, List<String>> {
        val raw = prefs(context).getString(PREFS_KEY, "{}") ?: "{}"
        val obj = JSONObject(raw)
        val out = LinkedHashMap<String, List<String>>()
        obj.keys().forEach { name ->
            val arr = obj.getJSONArray(name)
            out[name] = (0 until arr.length()).map { arr.getString(it) }
        }
        return out
    }

    fun saveRoutine(context: Context, name: String, steps: List<String>) {
        val raw = prefs(context).getString(PREFS_KEY, "{}") ?: "{}"
        val obj = JSONObject(raw)
        obj.put(name.trim().lowercase(), JSONArray(steps))
        prefs(context).edit().putString(PREFS_KEY, obj.toString()).apply()
    }

    fun deleteRoutine(context: Context, name: String) {
        val raw = prefs(context).getString(PREFS_KEY, "{}") ?: "{}"
        val obj = JSONObject(raw)
        obj.remove(name.trim().lowercase())
        prefs(context).edit().putString(PREFS_KEY, obj.toString()).apply()
    }

    fun getRoutine(context: Context, name: String): List<String>? {
        val raw = prefs(context).getString(PREFS_KEY, "{}") ?: "{}"
        val obj = JSONObject(raw)
        val key = name.trim().lowercase()
        if (!obj.has(key)) return null
        val arr = obj.getJSONArray(key)
        return (0 until arr.length()).map { arr.getString(it) }
    }

    /** Finds a routine whose name is contained in (or contains) the spoken text. */
    fun findMatchingRoutine(context: Context, spokenText: String): String? {
        val lower = spokenText.lowercase()
        return listRoutines(context).keys.firstOrNull { lower.contains(it) }
    }
}
