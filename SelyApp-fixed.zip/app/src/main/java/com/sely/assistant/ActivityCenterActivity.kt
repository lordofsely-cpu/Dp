package com.sely.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.sely.assistant.engine.ActionEngine
import com.sely.assistant.engine.ActionStep
import com.sely.assistant.engine.ActionType
import com.sely.assistant.engine.TaskMemory

class ActivityCenterActivity : AppCompatActivity() {

    private val actionEngine by lazy { ActionEngine(this) }
    private lateinit var statusBlock: TextView
    private lateinit var testResultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activity_center)

        statusBlock = findViewById(R.id.statusBlock)
        testResultText = findViewById(R.id.testResultText)

        findViewById<ImageButton>(R.id.backButton).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.refreshButton).setOnClickListener { refreshStatus() }

        findViewById<Button>(R.id.testSpeakButton).setOnClickListener {
            runTest(ActionStep(ActionType.DEVICE_INFO)) // harmless, exercises the full pipeline
        }
        findViewById<Button>(R.id.testFlashlightButton).setOnClickListener {
            runTest(ActionStep(ActionType.CONTROL_FLASHLIGHT, "on"))
            android.os.Handler(mainLooper).postDelayed({
                actionEngine.execute(ActionStep(ActionType.CONTROL_FLASHLIGHT, "off"))
            }, 700)
        }
        findViewById<Button>(R.id.testReadScreenButton).setOnClickListener {
            runTest(ActionStep(ActionType.READ_SCREEN))
        }
        findViewById<Button>(R.id.testDeviceInfoButton).setOnClickListener {
            runTest(ActionStep(ActionType.BATTERY_INFO))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun runTest(step: ActionStep) {
        val result = actionEngine.execute(step)
        testResultText.text = "${step.type}: ${if (result.success) "OK" else "FAILED"} \u2014 ${result.message}"
        refreshStatus()
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)
        val backendUrl = prefs.getString("backend_url", "") ?: ""
        val apiStatus = if (backendUrl.isEmpty()) "API UNAVAILABLE (no backend URL set)" else "CONFIGURED ($backendUrl)"
        val netStatus = if (isInternetAvailable()) "ONLINE" else "OFFLINE"
        val accessibilityStatus = if (SelyAccessibilityService.isRunning()) "RUNNING" else "NOT RUNNING"
        val lastAction = TaskMemory.lastAction
        val lastResult = TaskMemory.lastActionResult

        statusBlock.text = buildString {
            appendLine("Network: $netStatus")
            appendLine("Backend: $apiStatus")
            appendLine("Accessibility Service: $accessibilityStatus")
            appendLine("Current app: ${SelyAccessibilityService.instance?.currentPackageName() ?: "unknown"}")
            appendLine("Last app opened: ${TaskMemory.lastAppOpened ?: "-"}")
            appendLine("Last search: ${TaskMemory.lastSearchQuery ?: "-"}")
            appendLine("Last action: ${lastAction?.type ?: "-"} ${if (lastAction != null) "(${lastAction.target})" else ""}")
            appendLine("Last result: ${if (lastResult == null) "-" else if (lastResult.success) "OK: ${lastResult.message}" else "FAILED: ${lastResult.message}"}")
            appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            append("App version: 1.0.0")
        }
    }

    private fun isInternetAvailable(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }
}
